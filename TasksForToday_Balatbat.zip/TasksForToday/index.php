<?php

// Start CodeIgniter using its normal public entry point.
require __DIR__ . '/public/index.php';
