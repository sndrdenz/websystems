# Tasks for Today Management System

This is a complete CodeIgniter 4 project for the IT0049 Technical Summative Assessment 1. It has a Welcome page showing today's tasks, a full Task List, a Profile for one demo user, and an About page naming Denzel Gavin Balatbat as the developer. The original project starter and its installed framework files are included.

## Run with XAMPP on Windows

1. Extract the archive so the project folder is `D:\xampp\htdocs\TasksForToday`. It contains its own `index.php`, `public/index.php`, `app`, and `vendor`. Do not open files under `app/Views` directly.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin/`, create an empty database named `tasks_for_today`, select that database, and use **Import** to load `database/tasks_for_today.sql`. The SQL file also creates the database if it does not exist.
4. Open `http://localhost/TasksForToday/`. The root `index.php` starts CodeIgniter, and the root `.htaccess` routes the other pages and CSS to `public/`.

The included `.env` uses the usual local XAMPP MySQL account (`root` with a blank password). If your MySQL account or port differs, edit `.env`. If Apache rewrite rules are unavailable, set `app.baseURL` in `.env` to `http://localhost/TasksForToday/public/` and open that URL instead. For hosting, replace the local `.env` settings with your host's values before uploading.

The migration and seeder files are also included for the assessment. On a **fresh, empty database**, you can run `D:\xampp\php\php.exe spark migrate` and then `D:\xampp\php\php.exe spark db:seed DemoSeeder` from the project folder instead of importing the SQL file. **Choose one database setup method; do not run both.**

The SQL import or seeder should be run once on an empty database. It creates eight tasks dated yesterday, today, and tomorrow, plus exactly one demo user. After a day passes, the Welcome page can be empty until new tasks are added or the database is reset and reseeded; the Task List still displays all seeded records.

## Required pages

| URL | Displays |
| --- | --- |
| `/` | Only tasks with today's date. |
| `/tasks` | Every task ordered by task date. |
| `/profile` | The single demo user from the database. |
| `/about` | The developer's name. |

## Submission

The `app/Database/Migrations` and `app/Database/Seeds` folders contain the database schema and sample records. Upload the project to your GitHub repository, deploy it to a PHP/MySQL host, configure its `.env` for that host, and submit your own repository and working hosted links. The project's `.gitignore` excludes `vendor` and `.env`; after cloning a GitHub copy, run `composer install` and create `.env` from `.env.example`.
