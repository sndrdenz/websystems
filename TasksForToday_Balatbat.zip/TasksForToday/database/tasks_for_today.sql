CREATE DATABASE IF NOT EXISTS tasks_for_today;
USE tasks_for_today;

CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    task_date DATE NOT NULL,
    created_at DATETIME NOT NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL
);

INSERT INTO tasks (title, status, task_date, created_at) VALUES
('Review the project requirements', 'completed', CURDATE() - INTERVAL 1 DAY, NOW()),
('Prepare the database tables', 'completed', CURDATE() - INTERVAL 1 DAY, NOW()),
('Check today''s team priorities', 'pending', CURDATE(), NOW()),
('Update the project documentation', 'in progress', CURDATE(), NOW()),
('Review the task list with the team', 'pending', CURDATE(), NOW()),
('Submit the daily progress report', 'completed', CURDATE(), NOW()),
('Plan tomorrow''s assignments', 'pending', CURDATE() + INTERVAL 1 DAY, NOW()),
('Prepare the next project check-in', 'pending', CURDATE() + INTERVAL 1 DAY, NOW());

INSERT INTO users (username, full_name, email, created_at) VALUES
('denzelbalatbat', 'Denzel Gavin F. Balatbat', 'balatbatdenzelg@gmail.com', NOW());
