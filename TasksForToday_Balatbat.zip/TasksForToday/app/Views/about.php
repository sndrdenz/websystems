<?= view('partials/header', ['pageTitle' => 'About', 'activePage' => 'about']) ?>

<section class="page-heading">
    <p class="eyebrow">ABOUT</p>
    <h1>About the system</h1>
    <p class="subtitle">A simple place to view daily and upcoming tasks.</p>
</section>

<section class="panel about-panel" aria-labelledby="developer-heading">
    <h2 id="developer-heading">Developer</h2>
    <p class="developer-name">Denzel Gavin Balatbat</p>
    <p>This Tasks for Today Management System was developed for the IT0049 Web System Technologies activity using CodeIgniter 4.</p>
</section>

<?= view('partials/footer') ?>
