<?= view('partials/header', ['pageTitle' => 'Profile', 'activePage' => 'profile']) ?>

<section class="page-heading">
    <p class="eyebrow">PROFILE</p>
    <h1>Demo user</h1>
    <p class="subtitle">The user record stored in the database.</p>
</section>

<section class="panel profile-panel" aria-labelledby="profile-heading">
    <h2 id="profile-heading">User information</h2>
    <?php if ($user === null): ?>
        <p class="empty">No demo user has been added yet.</p>
    <?php else: ?>
        <dl class="details">
            <div><dt>Full name</dt><dd><?= esc($user['full_name']) ?></dd></div>
            <div><dt>Username</dt><dd><?= esc($user['username']) ?></dd></div>
            <div><dt>Email</dt><dd><?= esc($user['email']) ?></dd></div>
            <div><dt>Created at</dt><dd><?= esc($user['created_at']) ?></dd></div>
        </dl>
    <?php endif; ?>
</section>

<?= view('partials/footer') ?>
