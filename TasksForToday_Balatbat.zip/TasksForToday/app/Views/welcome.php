<?= view('partials/header', ['pageTitle' => 'Welcome', 'activePage' => 'welcome']) ?>

<section class="page-heading">
    <p class="eyebrow">WELCOME</p>
    <h1>Tasks for today</h1>
    <p class="subtitle">Your tasks for <?= esc(date('F j, Y', strtotime($today))) ?>.</p>
</section>

<section class="panel" aria-labelledby="today-heading">
    <div class="section-heading">
        <h2 id="today-heading">Today's tasks</h2>
        <span class="count"><?= count($tasks) ?> <?= count($tasks) === 1 ? 'task' : 'tasks' ?></span>
    </div>
    <?php if (empty($tasks)): ?>
        <p class="empty">No tasks are scheduled for today.</p>
    <?php else: ?>
        <div class="task-list">
            <?php foreach ($tasks as $task): ?>
                <div class="task-row">
                    <span class="task-title"><?= esc($task['title']) ?></span>
                    <span class="status"><?= esc(ucfirst($task['status'])) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?= view('partials/footer') ?>
