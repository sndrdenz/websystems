<?= view('partials/header', ['pageTitle' => 'Task List', 'activePage' => 'tasks']) ?>

<section class="page-heading">
    <p class="eyebrow">TASK LIST</p>
    <h1>All tasks</h1>
    <p class="subtitle">Every task in the database, ordered by date.</p>
</section>

<section class="panel" aria-labelledby="all-heading">
    <div class="section-heading">
        <h2 id="all-heading">Task list</h2>
        <span class="count"><?= count($tasks) ?> <?= count($tasks) === 1 ? 'task' : 'tasks' ?></span>
    </div>
    <?php if (empty($tasks)): ?>
        <p class="empty">There are no tasks to display.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th scope="col">Task</th><th scope="col">Date</th><th scope="col">Status</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                        <tr>
                            <td class="task-title"><?= esc($task['title']) ?></td>
                            <td><?= esc($task['task_date']) ?></td>
                            <td><span class="status"><?= esc(ucfirst($task['status'])) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?= view('partials/footer') ?>
