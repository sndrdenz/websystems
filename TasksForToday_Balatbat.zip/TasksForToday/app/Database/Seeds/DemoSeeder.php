<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DemoSeeder extends Seeder
{
    public function run()
    {
        date_default_timezone_set('Asia/Manila');

        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $today = date('Y-m-d');
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        $createdAt = date('Y-m-d H:i:s');

        $this->db->table('tasks')->insertBatch([
            ['title' => 'Review the project requirements', 'status' => 'completed', 'task_date' => $yesterday, 'created_at' => $createdAt],
            ['title' => 'Prepare the database tables', 'status' => 'completed', 'task_date' => $yesterday, 'created_at' => $createdAt],
            ['title' => 'Check today's team priorities', 'status' => 'pending', 'task_date' => $today, 'created_at' => $createdAt],
            ['title' => 'Update the project documentation', 'status' => 'in progress', 'task_date' => $today, 'created_at' => $createdAt],
            ['title' => 'Review the task list with the team', 'status' => 'pending', 'task_date' => $today, 'created_at' => $createdAt],
            ['title' => 'Submit the daily progress report', 'status' => 'completed', 'task_date' => $today, 'created_at' => $createdAt],
            ['title' => 'Plan tomorrow's assignments', 'status' => 'pending', 'task_date' => $tomorrow, 'created_at' => $createdAt],
            ['title' => 'Prepare the next project check-in', 'status' => 'pending', 'task_date' => $tomorrow, 'created_at' => $createdAt],
        ]);

        $this->db->table('users')->insert([
            'username' => 'denzelbalatbat',
            'full_name' => 'Denzel Gavin Balatbat',
            'email' => 'denzel.balatbat@example.com',
            'created_at' => $createdAt,
        ]);
    }
}
