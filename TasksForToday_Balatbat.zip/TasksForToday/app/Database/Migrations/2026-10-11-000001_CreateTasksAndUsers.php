<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateTasksAndUsers extends Migration
{
    public function up()
    {
        $this->db->query("CREATE TABLE tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(150) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            task_date DATE NOT NULL,
            created_at DATETIME NOT NULL
        )");

        $this->db->query("CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            created_at DATETIME NOT NULL
        )");
    }

    public function down()
    {
        $this->forge->dropTable('users', true);
        $this->forge->dropTable('tasks', true);
    }
}
