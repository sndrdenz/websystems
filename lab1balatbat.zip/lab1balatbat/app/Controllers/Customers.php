<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index(): string
    {
        $customers = [
            ['name' => 'Ava Santos', 'email' => 'ava.santos@example.com', 'status' => 'Active'],
            ['name' => 'Liam Cruz', 'email' => 'liam.cruz@example.com', 'status' => 'Active'],
            ['name' => 'Mia Reyes', 'email' => 'mia.reyes@example.com', 'status' => 'Pending'],
            ['name' => 'Noah Garcia', 'email' => 'noah.garcia@example.com', 'status' => 'Active'],
            ['name' => 'Ella Flores', 'email' => 'ella.flores@example.com', 'status' => 'Inactive'],
        ];

        return view('customers', ['customers' => $customers]);
    }
}
