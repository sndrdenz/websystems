<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index(): string
    {
        $users = [
            ['name' => 'Olivia Martin', 'role' => 'Administrator', 'lastLogin' => 'Today'],
            ['name' => 'Ethan Lee', 'role' => 'Manager', 'lastLogin' => 'Yesterday'],
            ['name' => 'Sophia Tan', 'role' => 'Editor', 'lastLogin' => '2 days ago'],
            ['name' => 'Lucas Wong', 'role' => 'Support', 'lastLogin' => '3 days ago'],
            ['name' => 'Isla Brown', 'role' => 'Viewer', 'lastLogin' => '1 week ago'],
        ];

        return view('users', ['users' => $users]);
    }
}
