<?php $title = 'User Accounts' ?>
<?= $this->include('partials/header') ?>

<section class="panel">
    <p class="eyebrow">Directory</p>
    <h1>User Accounts</h1>
    <p class="lede">A temporary sample list of users and their access roles.</p>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Last login</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= esc($user['name']) ?></td>
                        <td><?= esc($user['role']) ?></td>
                        <td class="status"><?= esc($user['lastLogin']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?= $this->include('partials/footer') ?>
