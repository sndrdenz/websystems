<?php $title = 'Customer Accounts' ?>
<?= $this->include('partials/header') ?>

<section class="panel">
    <p class="eyebrow">Directory</p>
    <h1>Customer Accounts</h1>
    <p class="lede">A temporary sample list of customer accounts.</p>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td><?= esc($customer['name']) ?></td>
                        <td><?= esc($customer['email']) ?></td>
                        <td class="status"><?= esc($customer['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?= $this->include('partials/footer') ?>
