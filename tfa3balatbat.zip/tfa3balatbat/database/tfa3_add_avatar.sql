-- IT0049 TFA3: upgrade an existing TFA2 database
-- BALATBAT, DENZEL GAVIN
-- Run this ONLY if you already imported the TFA2 version of pos_db.sql.
-- Fresh installs should import database/pos_db.sql, which already has the column.
-- Select the pos_db database (or your hosting database) before running.

ALTER TABLE users
  ADD COLUMN avatar VARCHAR(255) NULL DEFAULT NULL AFTER full_name;
