<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\RedirectResponse;

class Customers extends BaseController
{
    /**
     * Validation rules shared by the create and update actions.
     */
    private function rules(): array
    {
        return [
            'full_name' => 'required|min_length[2]|max_length[100]',
            'email'     => 'required|valid_email|max_length[100]',
            'phone'     => 'permit_empty|max_length[20]|regex_match[/^[0-9+\-\s()]+$/]',
        ];
    }

    private function messages(): array
    {
        return [
            'full_name' => [
                'required'   => 'Full name is required.',
                'min_length' => 'Full name must be at least 2 characters long.',
                'max_length' => 'Full name cannot be longer than 100 characters.',
            ],
            'email' => [
                'required'    => 'Email address is required.',
                'valid_email' => 'Please enter a valid email address, such as name@example.com.',
                'max_length'  => 'Email address cannot be longer than 100 characters.',
            ],
            'phone' => [
                'max_length'  => 'Phone number cannot be longer than 20 characters.',
                'regex_match' => 'Phone number may only contain digits, spaces, +, -, and parentheses.',
            ],
        ];
    }

    /**
     * Collect the editable fields from the submitted form.
     * An empty phone is stored as NULL because the column is optional.
     */
    private function formData(): array
    {
        $phone = trim((string) $this->request->getPost('phone'));

        return [
            'full_name' => trim((string) $this->request->getPost('full_name')),
            'email'     => trim((string) $this->request->getPost('email')),
            'phone'     => $phone === '' ? null : $phone,
        ];
    }

    public function index(): string
    {
        $customerModel = new CustomerModel();
        $customers = $customerModel->orderBy('id', 'ASC')->findAll();

        return view('customers', ['customers' => $customers]);
    }

    /**
     * GET /customers/new - blank form.
     */
    public function new(): string
    {
        return view('customer_form', [
            'mode'     => 'new',
            'customer' => null,
        ]);
    }

    /**
     * POST /customers/create - validate, then insert.
     */
    public function create(): RedirectResponse
    {
        if (! $this->validate($this->rules(), $this->messages())) {
            return redirect()->to('customers/new')
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $customerModel = new CustomerModel();
        $customerModel->insert($this->formData() + ['created_at' => date('Y-m-d H:i:s')]);

        return redirect()->to('customers')->with('success', 'Customer added successfully.');
    }

    /**
     * GET /customers/edit/{id} - form pre-filled with the existing record.
     */
    public function edit(int $id): string
    {
        $customer = (new CustomerModel())->find($id);

        if ($customer === null) {
            throw PageNotFoundException::forPageNotFound('Customer not found.');
        }

        return view('customer_form', [
            'mode'     => 'edit',
            'customer' => $customer,
        ]);
    }

    /**
     * POST /customers/update/{id} - validate, then update.
     */
    public function update(int $id): RedirectResponse
    {
        $customerModel = new CustomerModel();

        if ($customerModel->find($id) === null) {
            throw PageNotFoundException::forPageNotFound('Customer not found.');
        }

        if (! $this->validate($this->rules(), $this->messages())) {
            return redirect()->to('customers/edit/' . $id)
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $customerModel->update($id, $this->formData());

        return redirect()->to('customers')->with('success', 'Customer updated successfully.');
    }
}
