<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\RedirectResponse;
use CodeIgniter\HTTP\Files\UploadedFile;
use Throwable;

class Users extends BaseController
{
    /** Avatar thumbnails are stored here (inside public/ so they can be displayed). */
    private const AVATAR_DIR = 'uploads/avatars/';

    /** Thumbnail edge length in pixels (square, centre-cropped). */
    private const AVATAR_SIZE = 200;

    private function messages(): array
    {
        return [
            'username' => [
                'required'    => 'Username is required.',
                'min_length'  => 'Username must be at least 3 characters long.',
                'max_length'  => 'Username cannot be longer than 50 characters.',
                'regex_match' => 'Username may only contain letters, numbers, dots, underscores, and hyphens.',
                'is_unique'   => 'That username is already taken. Please choose another one.',
            ],
            'full_name' => [
                'required'   => 'Full name is required.',
                'min_length' => 'Full name must be at least 2 characters long.',
                'max_length' => 'Full name cannot be longer than 100 characters.',
            ],
            'avatar' => [
                'uploaded'  => 'The profile picture could not be uploaded. Choose a JPG or PNG file no larger than 2MB.',
                'is_image'  => 'The profile picture must be a valid image file.',
                'mime_in'   => 'The profile picture must be a genuine JPG or PNG image whose contents match its file extension.',
                'ext_in'    => 'The profile picture must be a genuine JPG or PNG image whose contents match its file extension.',
                'max_size'  => 'The profile picture must not be larger than 2MB.',
            ],
        ];
    }

    private function formData(): array
    {
        return [
            'username'  => trim((string) $this->request->getPost('username')),
            'full_name' => trim((string) $this->request->getPost('full_name')),
        ];
    }

    public function index(): string
    {
        $userModel = new UserModel();
        $users = $userModel->orderBy('id', 'ASC')->findAll();

        return view('users', ['users' => $users]);
    }

    /**
     * GET /users/new - blank form.
     */
    public function new(): string
    {
        return view('user_form', [
            'mode' => 'new',
            'user' => null,
        ]);
    }

    /**
     * POST /users/create - validate (username required + unique, full name required), then insert.
     */
    public function create(): RedirectResponse
    {
        $rules = [
            'username'  => 'required|min_length[3]|max_length[50]|regex_match[/^[A-Za-z0-9._-]+$/]|is_unique[users.username]',
            'full_name' => 'required|min_length[2]|max_length[100]',
        ];

        if (! $this->validate($rules, $this->messages())) {
            return redirect()->to('users/new')
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $userModel = new UserModel();
        $userModel->insert($this->formData() + ['created_at' => date('Y-m-d H:i:s')]);

        return redirect()->to('users')->with('success', 'User added successfully.');
    }

    /**
     * GET /users/edit/{id} - form pre-filled with the existing record.
     */
    public function edit(int $id): string
    {
        $user = (new UserModel())->find($id);

        if ($user === null) {
            throw PageNotFoundException::forPageNotFound('User not found.');
        }

        return view('user_form', [
            'mode' => 'edit',
            'user' => $user,
        ]);
    }

    /**
     * POST /users/update/{id} - validate, prepare the avatar thumbnail, then update.
     * Only the generated filename is stored in the avatar column.
     */
    public function update(int $id): RedirectResponse
    {
        $userModel = new UserModel();
        $user      = $userModel->find($id);

        if ($user === null) {
            throw PageNotFoundException::forPageNotFound('User not found.');
        }

        // The username must stay unique, but the user may keep their own current username.
        $rules = [
            'username'  => 'required|min_length[3]|max_length[50]|regex_match[/^[A-Za-z0-9._-]+$/]|is_unique[users.username,id,' . $id . ']',
            'full_name' => 'required|min_length[2]|max_length[100]',
        ];

        // The avatar is optional, so its file rules only apply when a file was actually chosen.
        $file      = $this->request->getFile('avatar');
        $hasUpload = $file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE;

        if ($hasUpload) {
            $rules['avatar'] = 'uploaded[avatar]'
                . '|max_size[avatar,2048]'
                . '|is_image[avatar]'
                . '|mime_in[avatar,image/jpg,image/jpeg,image/png]'
                . '|ext_in[avatar,jpg,jpeg,png]';
        }

        if (! $this->validate($rules, $this->messages())) {
            return redirect()->to('users/edit/' . $id)
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $data = $this->formData();

        $newAvatar = null;

        if ($hasUpload) {
            try {
                $newAvatar = $this->prepareAvatar($file, $id);
            } catch (Throwable $e) {
                log_message('error', 'Avatar processing failed: ' . $e->getMessage());

                return redirect()->to('users/edit/' . $id)
                    ->withInput()
                    ->with('errors', ['avatar' => 'The profile picture could not be processed. Please try a different JPG or PNG file.']);
            }

            $data['avatar'] = $newAvatar;
        }

        if (! $userModel->update($id, $data)) {
            // Do not leave an orphaned file behind if the database update failed.
            if ($newAvatar !== null) {
                $this->deleteAvatarFile($newAvatar);
            }

            return redirect()->to('users/edit/' . $id)
                ->withInput()
                ->with('errors', ['username' => 'The user could not be saved. Please try again.']);
        }

        // The new avatar is saved, so the replaced one is no longer needed.
        if ($newAvatar !== null && ! empty($user['avatar'])) {
            $this->deleteAvatarFile($user['avatar']);
        }

        return redirect()->to('users')->with('success', 'User updated successfully.');
    }

    /**
     * Create a display-ready square thumbnail from the upload and save it in public/uploads/avatars.
     * The original upload is never stored, and the stored name is generated (never the client's name).
     *
     * @return string the filename to store in the avatar column
     */
    private function prepareAvatar(UploadedFile $file, int $userId): string
    {
        $directory = FCPATH . self::AVATAR_DIR;

        if (! is_dir($directory) && ! mkdir($directory, 0755, true) && ! is_dir($directory)) {
            throw new \RuntimeException('Could not create the avatar upload directory.');
        }

        // The extension comes from the detected MIME type, not from the client-supplied name.
        $extension = $file->getMimeType() === 'image/png' ? 'png' : 'jpg';
        $filename  = 'user_' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $extension;

        service('image')
            ->withFile($file->getRealPath())
            ->reorient(true)                                  // honour camera rotation (EXIF)
            ->fit(self::AVATAR_SIZE, self::AVATAR_SIZE, 'center') // square crop + resize
            ->save($directory . $filename, 90);

        return $filename;
    }

    private function deleteAvatarFile(string $filename): void
    {
        // basename() keeps this restricted to the avatar folder.
        $path = FCPATH . self::AVATAR_DIR . basename($filename);

        if (is_file($path)) {
            @unlink($path);
        }
    }
}
