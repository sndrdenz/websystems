<?php
$isEdit = ($mode ?? 'new') === 'edit';
$title  = $isEdit ? 'Edit Customer' : 'New Customer';
$errors = session()->getFlashdata('errors') ?? [];
$action = $isEdit ? site_url('customers/update/' . $customer['id']) : site_url('customers/create');
?>
<?= $this->include('partials/header') ?>

<section class="panel form-panel">
    <p class="eyebrow"><?= $isEdit ? 'Update record' : 'Create record' ?></p>
    <h1><?= esc($title) ?></h1>
    <p class="lede"><?= $isEdit ? 'Update this customer\'s details and save your changes.' : 'Add a new customer to the directory.' ?></p>

    <?php if (! empty($errors)): ?>
        <div class="alert alert-error" role="alert">
            <strong>Please fix the following:</strong>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?= form_open($action, ['novalidate' => 'novalidate']) ?>
        <div class="field<?= isset($errors['full_name']) ? ' has-error' : '' ?>">
            <label for="full_name">Full name <span class="req">*</span></label>
            <input type="text" id="full_name" name="full_name" maxlength="100" autocomplete="name"
                   value="<?= esc(old('full_name', $customer['full_name'] ?? ''), 'attr') ?>">
            <?php if (isset($errors['full_name'])): ?><p class="field-error"><?= esc($errors['full_name']) ?></p><?php endif; ?>
        </div>

        <div class="field<?= isset($errors['email']) ? ' has-error' : '' ?>">
            <label for="email">Email <span class="req">*</span></label>
            <input type="email" id="email" name="email" maxlength="100" autocomplete="email"
                   value="<?= esc(old('email', $customer['email'] ?? ''), 'attr') ?>">
            <?php if (isset($errors['email'])): ?><p class="field-error"><?= esc($errors['email']) ?></p><?php endif; ?>
        </div>

        <div class="field<?= isset($errors['phone']) ? ' has-error' : '' ?>">
            <label for="phone">Phone <span class="optional">(optional)</span></label>
            <input type="text" id="phone" name="phone" maxlength="20" inputmode="tel" autocomplete="tel"
                   value="<?= esc(old('phone', $customer['phone'] ?? ''), 'attr') ?>">
            <?php if (isset($errors['phone'])): ?><p class="field-error"><?= esc($errors['phone']) ?></p><?php endif; ?>
        </div>

        <div class="actions">
            <button type="submit" class="button"><?= $isEdit ? 'Save changes' : 'Add customer' ?></button>
            <a class="button secondary" href="<?= site_url('customers') ?>">Cancel</a>
        </div>
    <?= form_close() ?>
</section>

<?= $this->include('partials/footer') ?>
