<?php
$isEdit = ($mode ?? 'new') === 'edit';
$title  = $isEdit ? 'Edit User' : 'New User';
$errors = session()->getFlashdata('errors') ?? [];
$action = $isEdit ? site_url('users/update/' . $user['id']) : site_url('users/create');

// Current avatar preview (edit page only).
$hasAvatar = $isEdit && ! empty($user['avatar']) && is_file(FCPATH . 'uploads/avatars/' . basename($user['avatar']));
$avatarSrc = $hasAvatar
    ? base_url('uploads/avatars/' . rawurlencode(basename($user['avatar'])))
    : base_url('images/avatar-placeholder.svg');
?>
<?= $this->include('partials/header') ?>

<section class="panel form-panel">
    <p class="eyebrow"><?= $isEdit ? 'Update record' : 'Create record' ?></p>
    <h1><?= esc($title) ?></h1>
    <p class="lede"><?= $isEdit ? 'Update this user\'s details or change their profile picture.' : 'Add a new user account to the directory.' ?></p>

    <?php if (! empty($errors)): ?>
        <div class="alert alert-error" role="alert">
            <strong>Please fix the following:</strong>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?= $isEdit
        ? form_open_multipart($action, ['novalidate' => 'novalidate'])
        : form_open($action, ['novalidate' => 'novalidate']) ?>
        <div class="field<?= isset($errors['username']) ? ' has-error' : '' ?>">
            <label for="username">Username <span class="req">*</span></label>
            <input type="text" id="username" name="username" maxlength="50" autocomplete="off"
                   value="<?= esc(old('username', $user['username'] ?? ''), 'attr') ?>">
            <p class="hint">Letters, numbers, dots, underscores, and hyphens. Must be unique.</p>
            <?php if (isset($errors['username'])): ?><p class="field-error"><?= esc($errors['username']) ?></p><?php endif; ?>
        </div>

        <div class="field<?= isset($errors['full_name']) ? ' has-error' : '' ?>">
            <label for="full_name">Full name <span class="req">*</span></label>
            <input type="text" id="full_name" name="full_name" maxlength="100" autocomplete="name"
                   value="<?= esc(old('full_name', $user['full_name'] ?? ''), 'attr') ?>">
            <?php if (isset($errors['full_name'])): ?><p class="field-error"><?= esc($errors['full_name']) ?></p><?php endif; ?>
        </div>

        <?php if ($isEdit): ?>
            <div class="field<?= isset($errors['avatar']) ? ' has-error' : '' ?>">
                <label for="avatar">Profile picture <span class="optional">(optional)</span></label>
                <div class="avatar-row">
                    <img class="avatar avatar-lg" id="avatar-preview" src="<?= esc($avatarSrc, 'attr') ?>" width="88" height="88" alt="Current profile picture">
                    <div>
                        <input type="file" id="avatar" name="avatar" accept="image/png,image/jpeg">
                        <p class="hint">JPG or PNG, up to 2MB. It will be cropped to a square thumbnail.<?= $hasAvatar ? ' Leave empty to keep the current picture.' : '' ?></p>
                    </div>
                </div>
                <?php if (isset($errors['avatar'])): ?><p class="field-error"><?= esc($errors['avatar']) ?></p><?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="actions">
            <button type="submit" class="button"><?= $isEdit ? 'Save changes' : 'Add user' ?></button>
            <a class="button secondary" href="<?= site_url('users') ?>">Cancel</a>
        </div>
    <?= form_close() ?>
</section>

<?php if ($isEdit): ?>
<script>
    // Show a quick preview of the chosen picture before submitting (the server still validates it).
    (function () {
        var input = document.getElementById('avatar');
        var preview = document.getElementById('avatar-preview');
        if (!input || !preview || !window.URL) { return; }
        input.addEventListener('change', function () {
            var file = input.files && input.files[0];
            if (file && /^image\/(png|jpeg)$/.test(file.type)) {
                preview.src = URL.createObjectURL(file);
            }
        });
    })();
</script>
<?php endif; ?>

<?= $this->include('partials/footer') ?>
