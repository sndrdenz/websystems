<?php $title = 'User Accounts' ?>
<?= $this->include('partials/header') ?>

<section class="panel">
    <div class="panel-head">
        <div>
            <p class="eyebrow">Directory</p>
            <h1>User Accounts</h1>
            <p class="lede">Browse user account information.</p>
        </div>
        <a class="button" href="<?= site_url('users/new') ?>">+ New user</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Avatar</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Date created</th>
                    <th class="col-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="6">No user accounts found.</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($users as $user): ?>
                    <?php
                    // Use the prepared thumbnail when one exists on disk; otherwise show the placeholder.
                    $hasAvatar = ! empty($user['avatar']) && is_file(FCPATH . 'uploads/avatars/' . basename($user['avatar']));
                    $avatarSrc = $hasAvatar
                        ? base_url('uploads/avatars/' . rawurlencode(basename($user['avatar'])))
                        : base_url('images/avatar-placeholder.svg');
                    ?>
                    <tr>
                        <td><?= esc($user['id']) ?></td>
                        <td>
                            <img class="avatar" src="<?= esc($avatarSrc, 'attr') ?>" width="44" height="44" alt="<?= $hasAvatar ? esc($user['full_name'], 'attr') . ' avatar' : 'No profile picture' ?>">
                        </td>
                        <td><?= esc($user['full_name']) ?></td>
                        <td><?= esc($user['username']) ?></td>
                        <td><?= esc($user['created_at']) ?></td>
                        <td class="col-actions">
                            <a class="button small secondary" href="<?= site_url('users/edit/' . $user['id']) ?>">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?= $this->include('partials/footer') ?>
