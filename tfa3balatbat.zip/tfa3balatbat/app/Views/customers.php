<?php $title = 'Customer Accounts' ?>
<?= $this->include('partials/header') ?>

<section class="panel">
    <div class="panel-head">
        <div>
            <p class="eyebrow">Directory</p>
            <h1>Customer Accounts</h1>
            <p class="lede">Browse customer account information.</p>
        </div>
        <a class="button" href="<?= site_url('customers/new') ?>">+ New customer</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Date registered</th>
                    <th class="col-actions">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($customers)): ?>
                    <tr>
                        <td colspan="6">No customer accounts found.</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td><?= esc($customer['id']) ?></td>
                        <td><?= esc($customer['full_name']) ?></td>
                        <td><?= esc($customer['email']) ?></td>
                        <td><?= esc($customer['phone'] ?? 'Not provided') ?></td>
                        <td><?= esc($customer['created_at']) ?></td>
                        <td class="col-actions">
                            <a class="button small secondary" href="<?= site_url('customers/edit/' . $customer['id']) ?>">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?= $this->include('partials/footer') ?>
