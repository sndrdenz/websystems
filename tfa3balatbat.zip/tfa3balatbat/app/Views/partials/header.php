<?php $currentPath = trim(uri_string(), '/'); ?>
<?php
// Marks the nav link for the section the visitor is currently in.
$isActive = static function (string $section) use ($currentPath): bool {
    if ($section === '') {
        return $currentPath === '';
    }

    return $currentPath === $section || str_starts_with($currentPath, $section . '/');
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Balatbat') ?> | Balatbat</title>
    <link rel="stylesheet" href="<?= base_url('css/site.css') ?>">
</head>
<body>
<header class="site-header">
    <a class="brand" href="<?= site_url('/') ?>">Balatbat</a>
    <nav aria-label="Main navigation">
        <a href="<?= site_url('/') ?>"<?= $isActive('') ? ' class="active" aria-current="page"' : '' ?>>Home</a>
        <a href="<?= site_url('about') ?>"<?= $isActive('about') ? ' class="active" aria-current="page"' : '' ?>>About</a>
        <a href="<?= site_url('customers') ?>"<?= $isActive('customers') ? ' class="active" aria-current="page"' : '' ?>>Customers</a>
        <a href="<?= site_url('users') ?>"<?= $isActive('users') ? ' class="active" aria-current="page"' : '' ?>>Users</a>
    </nav>
</header>
<main>
<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success" role="status"><?= esc(session()->getFlashdata('success')) ?></div>
<?php endif; ?>
