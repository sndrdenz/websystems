<?php

// Created by BALATBAT, DENZEL GAVIN.

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = ['username', 'full_name', 'avatar', 'created_at'];
    protected $useTimestamps = false;
}
