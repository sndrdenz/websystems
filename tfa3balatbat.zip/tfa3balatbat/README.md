# IT0049 TFA3 — Making It Editable: Forms, Validation, and File Upload

**Student:** BALATBAT, DENZEL GAVIN  
**Base project:** The `lab1balatbat` CodeIgniter POS application from TFA2 (which extended TFA1)

TFA3 adds validated create/edit forms for customers and users, and avatar upload with thumbnail preparation for users. See [TFA3 features](#tfa3-features) below. The TFA2 notes that follow still apply.

---

## TFA2 background

TFA2 extended TFA1 with a MySQL database. Customer Accounts and User Accounts now retrieve records through CodeIgniter Models using `orderBy('id', 'ASC')->findAll()`. The original home page, about page, navigation, routes, and stylesheet are retained.

## TFA3 features

| Requirement | Where it lives |
| --- | --- |
| 1. New Customer form, `/customers/new` (full name required; email required and valid) | `Customers::new()` and `Customers::create()`, view `customer_form.php` |
| 2. New User form, `/users/new` (username required and unique; full name required) | `Users::new()` and `Users::create()`, view `user_form.php` |
| 3. Edit pages that pre-fill the record and update on submit | `/customers/edit/{id}` and `/users/edit/{id}`, handled by `edit()` and `update()` in each controller |
| 4. `avatar` column on `users`; JPG/PNG up to 2MB; thumbnail stored in a public folder; filename only in the database | `Users::update()` and `Users::prepareAvatar()`, `public/uploads/avatars/` |
| 5. Avatar (or placeholder) on the User Accounts listing | `app/Views/users.php`, `public/images/avatar-placeholder.svg` |

### Routes

| Method | URL | Action |
| --- | --- | --- |
| GET | `/customers/new` | Blank customer form |
| POST | `/customers/create` | Validate, then insert |
| GET | `/customers/edit/{id}` | Customer form pre-filled with the record |
| POST | `/customers/update/{id}` | Validate, then update |
| GET | `/users/new` | Blank user form |
| POST | `/users/create` | Validate, then insert |
| GET | `/users/edit/{id}` | User form pre-filled, including the avatar upload |
| POST | `/users/update/{id}` | Validate, prepare avatar, then update |

Unknown ids return the framework's 404 page.

### Validation

| Field | Rules |
| --- | --- |
| Customer `full_name` | required, 2–100 characters |
| Customer `email` | required, valid email address, up to 100 characters |
| Customer `phone` | optional, up to 20 characters, digits / spaces / `+` `-` `(` `)` only; empty is saved as NULL |
| User `username` | required, 3–50 characters, letters / numbers / `.` `_` `-` only, **unique** (`is_unique[users.username]`). On edit the rule ignores the user's own row (`is_unique[users.username,id,{id}]`), so saving without changing the username works |
| User `full_name` | required, 2–100 characters |
| User `avatar` (edit form, optional) | `uploaded`, `max_size[avatar,2048]` (2MB), `is_image`, `mime_in` (JPG/PNG), `ext_in` (jpg/jpeg/png) |

When validation fails the user is redirected back to the same form, which shows an error summary plus a message under each invalid field. The values they typed are kept using `old()`. Every message is escaped with `esc()`.

### Avatar upload

1. The file is checked with the rules above. CodeIgniter's strict file rules check the real file contents, so a PHP script renamed to `.jpg` is rejected, and so is a PNG renamed to `.jpg`.
2. `prepareAvatar()` uses the Image service (GD) to correct camera rotation (`reorient`), crop to a centred square and resize to **200x200** (`fit`), then saves it as JPG or PNG. Only this prepared thumbnail is stored; the original upload is discarded.
3. The file name is generated (`user_{id}_{random}.jpg|png`), never taken from the client, so names cannot collide or contain paths.
4. It is saved in **`public/uploads/avatars/`**, and only the **filename** goes in `users.avatar`. Pages build the URL with `base_url('uploads/avatars/' . $filename)`.
5. When a user's picture is replaced, the previous file is deleted. If the database update fails, the new file is removed.
6. Editing a user without choosing a file keeps the current picture. Users with no avatar (or whose file is missing) show `public/images/avatar-placeholder.svg`.

`public/uploads/avatars/.htaccess` blocks script execution in the upload folder as an extra safeguard.

### Other changes

- CSRF protection is enabled globally in `app/Config/Filters.php`. Forms are built with `form_open()` / `form_open_multipart()`, which add the token automatically.
- `BaseController` now loads the `form` and `url` helpers.
- Models: `avatar` was added to `UserModel::$allowedFields`.
- Success messages (added / updated) appear after saving through flash data.
- Slight UI refresh in `public/css/site.css`: sans-serif body text with the original serif headings, highlighted current page in the nav, button and row hover states, form, alert and avatar styles, and "New" / "Edit" buttons on both lists. Layout, colours and navigation are otherwise unchanged.

### Database for TFA3

`database/pos_db.sql` now creates `users` with `avatar VARCHAR(255) NULL`. For a **fresh** install just import this file as before.

If you already imported the TFA2 database and want to keep it, run **`database/tfa3_add_avatar.sql`** instead (a single `ALTER TABLE users ADD COLUMN avatar ...`).

### Requirements added by TFA3

- PHP **GD** extension (`extension=gd` in `php.ini`; enabled by default in XAMPP) for thumbnail creation.
- `public/uploads/avatars/` must be writable by the web server. On Linux hosting: `chmod -R 775 public/uploads`.
- PHP `upload_max_filesize` and `post_max_size` of at least 2MB (XAMPP's defaults are higher than this; the stock PHP default of 2MB is borderline).

### Try it (checklist)

1. Import `database/pos_db.sql` (or run `tfa3_add_avatar.sql` on an existing TFA2 database).
2. Customers: open **New customer** and submit it empty, then with a bad email, and check the errors and kept values. Then add a valid customer and use **Edit** on a row.
3. Users: open **New user**. Try an empty form, then `olivia.martin` (taken), then a new username.
4. Open **Edit** on a user and upload a JPG/PNG. The list should show the square thumbnail.
5. Try a `.gif`, a file over 2MB, and a text file renamed to `.jpg`; each should be rejected with a message and leave the avatar unchanged.
6. Save a user without choosing a file: the current avatar stays.

### Testing note

These flows were run against a real PHP 8.3 + MariaDB instance using CodeIgniter's development server: invalid and valid creates and updates for both record types, duplicate-username checks (including editing without changing the username), CSRF rejection of a POST with no token, uploads of JPG, JPEG, uppercase `.JPG` and PNG with transparency, rejection of GIF, PHP-as-JPG, PNG-renamed-JPG and over-2MB files, thumbnail size (200x200), filename-only storage, deletion of replaced avatars, and the placeholder fallback. It was not tested in XAMPP/Apache itself or on a hosting provider, so run the checklist above on your own setup before submitting.

---

## Requirements

- PHP 8.2 or higher compatible with the included Composer dependencies.
- PHP extensions `intl`, `mbstring`, and `mysqli` with mysqlnd enabled.
- MySQL or a compatible MariaDB server (such as the database bundled with XAMPP).
- Apache with `mod_rewrite` and `.htaccess` overrides enabled for the XAMPP setup below.
- Composer if installing dependencies from a GitHub clone. The ZIP includes the original `vendor` directory.

## Run locally with XAMPP

1. Extract the ZIP. Put the inner **lab1balatbat** folder in `C:\xampp\htdocs\` so that `C:\xampp\htdocs\lab1balatbat\spark` exists. Avoid an extra nested project folder.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin/`, choose **Import**, select `database/pos_db.sql` from the project, and click **Go**. The SQL creates `pos_db`, the two required tables, and five records per table. Import it once into a new database; it deliberately does not drop existing tables.
4. The ZIP includes a configured `.env`. If working from a GitHub clone, copy `.env.example` to `.env` first:

   ```powershell
   Copy-Item .env.example .env
   ```

5. Confirm these settings in `.env` match your own local MySQL installation:

   ```ini
   CI_ENVIRONMENT = development
   app.baseURL = 'http://localhost/lab1balatbat/'

   database.default.hostname = localhost
   database.default.database = pos_db
   database.default.username = root
   database.default.password = ''
   database.default.DBDriver = MySQLi
   database.default.DBPrefix = ''
   database.default.port = 3306
   ```

   The empty password is the local XAMPP default. Set your actual password if you changed it. If you change the folder name or Apache port, update `app.baseURL` as well.

6. For a GitHub clone without `vendor`, open a terminal in the project folder and run `composer install`. The supplied ZIP already includes TFA1's dependencies.
7. Visit:

   | Page | Local URL |
   | --- | --- |
   | Home | http://localhost/lab1balatbat/ |
   | About | http://localhost/lab1balatbat/about |
   | Customer Accounts | http://localhost/lab1balatbat/customers |
   | User Accounts | http://localhost/lab1balatbat/users |

The root `.htaccess` retains TFA1's forwarding to `public/` and includes a guard against repeatedly adding `public/` during internal rewrites.

### Alternative: CodeIgniter development server

Keep MySQL running and import the database first. In `.env`, change `app.baseURL` to `http://localhost:8080/`. From the project folder run:

```bash
php spark serve
```

Open `http://localhost:8080/`. Use this base URL for the other routes too.

## Database and application changes

The SQL export is **database/pos_db.sql**. It contains the exact table definitions supplied in the activity:

| Table | Fields |
| --- | --- |
| `customers` | `id` INT auto-increment primary key; `full_name` VARCHAR(100) required; `email` VARCHAR(100) required; `phone` VARCHAR(20) nullable; `created_at` DATETIME required |
| `users` | `id` INT auto-increment primary key; `username` VARCHAR(50) required and unique; `full_name` VARCHAR(100) required; `created_at` DATETIME required |

The sample names are retained from TFA1. Customer phone numbers are fictional strings that retain their leading zero. Mia Reyes has a NULL phone to demonstrate the optional field. Both tables have five sample rows with explicit creation dates.

| File | Purpose |
| --- | --- |
| `app/Models/CustomerModel.php` | Maps the `customers` table and its allowed fields. |
| `app/Models/UserModel.php` | Maps the `users` table and its allowed fields. |
| `app/Controllers/Customers.php` | Retrieves customers through `CustomerModel` and passes them to the existing view. |
| `app/Controllers/Users.php` | Retrieves users through `UserModel` and passes them to the existing view. |
| `app/Views/customers.php` | Displays customer ID, name, email, phone, and registration date. |
| `app/Views/users.php` | Displays user ID, name, username, and creation date. |
| `.env` / `.env.example` | Configures the MySQL connection and local base URL. |

`findAll()` uses the framework's Query Builder internally. Neither controller contains raw SQL or sample account arrays. Models return associative arrays, so the views keep the original `foreach` table structure and escape displayed values with `esc()`. Empty tables display a short message, and NULL phone values display “Not provided”.

The old customer status and user role/last-login columns were replaced because those fields do not exist in the required TFA2 schema. TFA2 added no extra columns (TFA3 adds only `users.avatar`). Automatic model timestamps are disabled because records supply `created_at` explicitly and the schema has no `updated_at` column. (TFA2 only displayed records; TFA3 adds the create and edit forms described above.)

## Verify on your computer

1. Confirm all four pages load and navigation and styling still work.
2. Confirm the customer page shows five records, including Ava Santos and Mia Reyes; Mia's phone should say “Not provided”.
3. Confirm the user page shows five records, including `olivia.martin` and `isla.brown`.
4. In phpMyAdmin, edit one sample customer's `full_name`, save it, and refresh Customer Accounts. The changed name should appear. Restore the original value afterward. This verifies that the displayed records come from the database.
5. Restart the local server and verify the saved records remain available.

Static checks were performed against the supplied DOCX schema, model/controller/view field mappings, sample records, and preservation of the original project. PHP execution, a real MySQL import, and browser rendering have not been verified in the preparation workspace because PHP and MySQL are unavailable there. Complete the checks above before submitting.

If a database connection fails, check that MySQL is running, `pos_db` exists, and the hostname, port, username, and password match `.env`. If clean routes return 404, check Apache's rewrite settings or use `php spark serve`. If PHP reports a missing extension, enable it in the PHP configuration used by that server and restart Apache.

## GitHub submission

The assignment requires a repository link containing the raw project files and SQL export.

1. Create or open your GitHub repository and open this project folder in VS Code.
2. Commit the raw project contents, including `app`, `public`, `database/pos_db.sql`, `.env.example`, `composer.json`, `composer.lock`, `spark`, and this README. Do not upload only the ZIP.
3. Use Source Control to commit and push/sync to your repository.
4. Keep `.env` private. The existing `.gitignore` excludes it, `vendor`, and runtime files. Anyone cloning the project can copy `.env.example` and run `composer install`.
5. Copy your actual repository URL into your submission.

## Hosted application submission

Use a host that supports PHP and MySQL. A static-only host cannot execute this CodeIgniter application.

1. Upload/deploy the project to your PHP host and install dependencies with `composer install --no-dev --optimize-autoloader`, or include a compatible `vendor` directory.
2. Point the site's document root to the project's **public** directory. Keep `app`, `vendor`, `.env`, and the SQL export outside that public document root.
3. Create the database through the host's control panel. If it assigns a database name, omit the `CREATE DATABASE` and `USE pos_db` statements from the SQL file, select the assigned database, and import the remaining table definitions and inserts.
4. Configure the host's `.env` with its database hostname, database name, username, password, and port. Set `app.baseURL` to the actual hosted URL with a trailing slash and `CI_ENVIRONMENT = production`.
5. Make the `writable` directory writable by the web server. Enable routing rewrites as required by the host.
6. Test all four pages and confirm both account tables display the imported records. Submit the actual hosted URL together with your GitHub URL.

**Submission status:** Project files and the SQL export are prepared. No GitHub repository has been pushed and no public hosting deployment has been created; those require your repository and hosting destination. For hosting, make sure `public/uploads/avatars/` exists and is writable and that PHP's GD extension is enabled.
